package phoneBook;

import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PhoneBookMain extends javafx.application.Application{
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage ps) throws Exception {
		URL resource = this.getClass().getResource("Contact.fxml");
		Parent root = FXMLLoader.load(resource);
		Scene sc = new Scene (root);
		ps.setScene(sc);
		ps.sizeToScene();
		ps.setTitle("Phone Book Please run");
		ps.show();
	}
}