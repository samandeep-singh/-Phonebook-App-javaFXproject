package phoneBook;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class PhoneBookController {
	@FXML private TextField txtName, txtPhone, txtEmail;
	@FXML private Button btnAddContact;
	
	@FXML public void doAction(ActionEvent e) {
		String name = txtName.getText();
		int phone = Integer.parseInt(txtPhone.getText());
		String email = txtEmail.getText();
	}

}
